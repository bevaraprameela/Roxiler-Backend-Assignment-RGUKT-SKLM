document.addEventListener('DOMContentLoaded', function () {
    const monthSelect = document.getElementById('month-select');
    const selectedMonthEl = document.getElementById('selected-month'); // Reference for the selected month element
  
    // Fetch data and render statistics
    async function loadData() {
      const selectedMonth = monthSelect.value;
  
      const stats = await fetchStatistics(selectedMonth);
      renderStatistics(stats, selectedMonth);
    }
  
    // Render statistics
    function renderStatistics(stats, selectedMonth) {
      document.getElementById('total-sales').textContent = stats.totalSales;
      document.getElementById('sold-items').textContent = stats.soldItems;
      document.getElementById('unsold-items').textContent = stats.unsoldItems;
      selectedMonthEl.textContent = selectedMonth;  // Update the displayed month in the statistics section
    }
  
    // Event listener for month select
    monthSelect.addEventListener('change', loadData);
  
    // Initial load
    loadData();
  });
  