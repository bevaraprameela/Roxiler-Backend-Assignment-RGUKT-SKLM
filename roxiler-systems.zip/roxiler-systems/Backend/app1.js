
app.get('/transactions', async (req, res) => {
  try {
    const { search = '', page = 1, perPage = 10 } = req.query;

    const searchFilter = search
      ? {
          $or: [
            { title: { $regex: search, $options: 'i' } },       
            { description: { $regex: search, $options: 'i' } }, 
            { price: { $regex: search, $options: 'i' } }      
          ]
        }
      : {};

    const limit = parseInt(perPage);
    const skip = (parseInt(page) - 1) * limit;

    const transactions = await Transaction.find(searchFilter)
      .skip(skip)
      .limit(limit);
    const totalTransactions = await Transaction.countDocuments(searchFilter);

    res.status(200).json({
      page: parseInt(page),
      perPage: limit,
      totalTransactions,
      totalPages: Math.ceil(totalTransactions / limit),
      transactions
    });
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Error fetching transactions' });
  }
});
