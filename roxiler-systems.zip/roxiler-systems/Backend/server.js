
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const dotenv = require('dotenv');
dotenv.config();

const app = express();


mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));

const transactionSchema = new mongoose.Schema({
  id: Number,
  title: String,
  description: String,
  category: String,
  price: Number,
  sold: Boolean,
  dateOfSale: Date
});


const Transaction = mongoose.model('Transaction', transactionSchema);


app.get('/statistics', async (req, res) => {
  try {
    const { month } = req.query;  

    if (!month) {
      return res.status(400).json({ error: 'Month is required' });
    }

    const monthInt = parseInt(month);
    if (monthInt < 1 || monthInt > 12) {
      return res.status(400).json({ error: 'Invalid month. Must be between 1 and 12.' });
    }

    
    const startDate = new Date(new Date().getFullYear(), monthInt - 1, 1); 
    const endDate = new Date(new Date().getFullYear(), monthInt, 0); 

   
    const transactions = await Transaction.find({
      dateOfSale: { $gte: startDate, $lt: endDate }
    });

  
    const totalSaleAmount = transactions.reduce((total, transaction) => {
      return total + (transaction.sold ? transaction.price : 0);
    }, 0);

    const totalSoldItems = transactions.filter(transaction => transaction.sold).length;
    const totalUnsoldItems = transactions.filter(transaction => !transaction.sold).length;


    res.status(200).json({
      totalSaleAmount,
      totalSoldItems,
      totalUnsoldItems
    });
  } catch (error) {
    console.error('Error fetching statistics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
