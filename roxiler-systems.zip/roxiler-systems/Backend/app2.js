
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const app = express();
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));
const transactionSchema = new mongoose.Schema({
  id: Number,
  title: String,
  description: String,
  category: String,
  price: Number,
  sold: Boolean,
  dateOfSale: Date
});

const Transaction = mongoose.model('Transaction', transactionSchema);
app.get('/bar-chart', async (req, res) => {
  try {
    const { month } = req.query;

    if (!month) {
      return res.status(400).json({ error: 'Month is required' });
    }
    const monthInt = parseInt(month);
    if (monthInt < 1 || monthInt > 12) {
      return res.status(400).json({ error: 'Invalid month. Must be between 1 and 12.' });
    }
    const startDate = new Date(new Date().getFullYear(), monthInt - 1, 1); 
    const endDate = new Date(new Date().getFullYear(), monthInt, 0);
    const transactions = await Transaction.find({
      dateOfSale: { $gte: startDate, $lt: endDate }
    });

    const priceRanges = {
      "0-100": 0,
      "101-200": 0,
      "201-300": 0,
      "301-400": 0,
      "401-500": 0,
      "501-600": 0,
      "601-700": 0,
      "701-800": 0,
      "801-900": 0,
      "901-above": 0
    }
    transactions.forEach(transaction => {
      const price = transaction.price;
      if (price >= 0 && price <= 100) priceRanges["0-100"]++;
      else if (price >= 101 && price <= 200) priceRanges["101-200"]++;
      else if (price >= 201 && price <= 300) priceRanges["201-300"]++;
      else if (price >= 301 && price <= 400) priceRanges["301-400"]++;
      else if (price >= 401 && price <= 500) priceRanges["401-500"]++;
      else if (price >= 501 && price <= 600) priceRanges["501-600"]++;
      else if (price >= 601 && price <= 700) priceRanges["601-700"]++;
      else if (price >= 701 && price <= 800) priceRanges["701-800"]++;
      else if (price >= 801 && price <= 900) priceRanges["801-900"]++;
      else priceRanges["901-above"]++;
    });

    res.status(200).json(priceRanges);

  } catch (error) {
    console.error('Error fetching bar chart data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
