// server.js
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config();

const app = express();

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));

// Define the schema for transactions
const transactionSchema = new mongoose.Schema({
  id: Number,
  title: String,
  description: String,
  category: String,
  price: Number,
  sold: Boolean,
  dateOfSale: Date
});

// Define the model
const Transaction = mongoose.model('Transaction', transactionSchema);

// Endpoint to fetch data from third-party API and store it in MongoDB
app.get('/initialize', async (req, res) => {
  try {
    // Fetch data from the third-party API
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    
    // Get the data from the response
    const transactions = response.data;

    // Clear the existing data in the collection (optional, if you want to start fresh)
    await Transaction.deleteMany({});

    // Insert the fetched data into the MongoDB collection
    await Transaction.insertMany(transactions);

    res.status(200).json({
      message: 'Database initialized with third-party data',
      totalRecords: transactions.length
    });
  } catch (error) {
    console.error('Error fetching and storing data:', error);
    res.status(500).json({ error: 'Error fetching data from third-party API' });
  }
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
